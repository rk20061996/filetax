














$(function() {
    // Owl Carousel
    var owl = $(".owl-carousel");
    owl.owlCarousel({
      items: 4,
      margin: 20,
      loop: true,
      nav: true
    });
  });
  


  if ($(window).width() > 319) {
    $(window).scroll(function() {   
    var scroll = $(window).scrollTop();
    if (scroll >= 1) {
        $(".navbar-default").addClass("sticky-navigation");
        $('body').addClass("sticky-nav")
    } else {
        $(".navbar-default").removeClass("sticky-navigation");
        $('body').removeClass("sticky-nav")
    }
});
    }